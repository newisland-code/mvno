// backend/src/middleware/injectAuthKey.ts

import { Request, Response, NextFunction } from "express";

export const injectAuthKey = (req: Request, res: Response, next: NextFunction) => {
  if (!process.env.AUTH_KEY) {
    return res.status(500).json({ error: "authKey is missing on server." });
  }
  // POSTリクエストならbodyに
  if (req.method === "POST") {
    req.body.authKey = process.env.AUTH_KEY;
  }
  // GETなどならqueryにも注入
  if (req.method === "GET") {
    req.query.authKey = process.env.AUTH_KEY;
  }
  next();
};

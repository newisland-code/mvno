// backend/src/routes/authOem.ts
import express from "express";
import fetch from "node-fetch";
import FormData from "form-data";

const router = express.Router();

router.post("/", async (req, res) => {
  const { oemId, oemPassword } = req.body;

  if (!oemId || !oemPassword) {
    return res.status(400).json({ error: "OEM IDとパスワードが必要です" });
  }

  const form = new FormData();
  form.append("json", JSON.stringify({ oemId, oemPassword }));

  try {
    const response = await fetch("https://i1.mvno.net/emptool/api/mvno/authOem/", {
      method: "POST",
      headers: form.getHeaders(),
      body: form as any,
    });

    const result = await response.json();

    if (result.resultCode !== "100") {
      return res.status(401).json({ error: "認証失敗", result });
    }

    res.json({ authKey: result.authKey });
  } catch (err: any) {
    console.error("OEM認証エラー:", err);
    res.status(500).json({ error: err.message });
  }
});

export default router;

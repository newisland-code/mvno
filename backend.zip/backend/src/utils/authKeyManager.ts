import fs from 'fs';
import path from 'path';
import fetch from 'node-fetch';
import dotenv from 'dotenv';

// .env をロード
dotenv.config();

const ENV_PATH = path.resolve(__dirname, '../../.env');

export const fetchAndStoreAuthKey = async () => {
  try {
    const oemId = process.env.OEM_ID;
    const oemKey = process.env.OEM_KEY;

    if (!oemId || !oemKey) {
      throw new Error('OEM_ID または OEM_KEY が .env に設定されていません。');
    }

    const response = await fetch('https://mvnoapi.freebit.com/emptool/api/authOem/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ oemId, oemKey })
    });

    if (!response.ok) {
      throw new Error(`認証に失敗しました: ${response.statusText}`);
    }

    const data = await response.json();
    const authKey = data.authKey;

    if (!authKey) {
      throw new Error('authKey の取得に失敗しました。');
    }

    let envContent = fs.readFileSync(ENV_PATH, 'utf8');

    if (envContent.includes('AUTH_KEY=')) {
      envContent = envContent.replace(/AUTH_KEY=.*/g, `AUTH_KEY=${authKey}`);
    } else {
      envContent += `\nAUTH_KEY=${authKey}`;
    }

    fs.writeFileSync(ENV_PATH, envContent);
    console.log('✅ authKey を .env に保存しました');
  } catch (error) {
    console.error('❌ authKey の取得と保存に失敗:', error);
  }
};

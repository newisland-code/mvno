import fetch, { RequestInit } from "node-fetch";

/**
 * 共通API POSTリクエスト関数
 * @param url - APIのURL
 * @param authKey - 認証トークン
 * @param payload - リクエストボディ
 */
export const postToApi = async (
  url: string,
  authKey: string,
  payload: Record<string, any>
) => {
  const options: RequestInit = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${authKey}`,
    },
    body: JSON.stringify(payload),
  };

  try {
    const response = await fetch(url, options);
    const text = await response.text();

    if (!response.ok) {
      throw new Error(`API Error ${response.status}: ${text}`);
    }

    try {
      return JSON.parse(text); // JSONで返ってこないこともあるため try
    } catch {
      return text;
    }
  } catch (error) {
    console.error("API呼び出しエラー:", error);
    throw error;
  }
};

import fetch from "node-fetch";
import FormData from "form-data";
import dotenv from "dotenv";
dotenv.config();

export async function getAuthKey(): Promise<string> {
  const { OEM_ID, OEM_KEY } = process.env;

  if (!OEM_ID || !OEM_KEY) {
    throw new Error("必要な環境変数が設定されていません");
  }

  const form = new FormData();
  form.append("json", JSON.stringify({ oemId: OEM_ID, oemKey: OEM_KEY }));

  const response = await fetch("https://i1.mvno.net/emptool/api/authOem/", {
    method: "POST",
    headers: form.getHeaders(),
    body: form as any,
  });

  const result = await response.json();

  if (result.resultCode === "100" && result.authKey) {
    return result.authKey;
  }

  throw new Error("FreeBitからauthKeyが取得できませんでした。");
}

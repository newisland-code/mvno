// frontend/src/types/ApiResponse.ts
export interface ApiResponse {
  resultCode: string;
  resultMessage: string;
}

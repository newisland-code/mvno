// frontend/src/types/EsimStatus.ts
export enum EsimStatus {
  PENDING = "PENDING",
  ACTIVATED = "ACTIVATED",
  CANCELLED = "CANCELLED",
  ERROR = "ERROR",
}

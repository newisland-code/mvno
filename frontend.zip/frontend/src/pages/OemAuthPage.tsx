// frontend/src/pages/OemAuthPage.tsx
import React from "react";
import OemAuthForm from "../components/forms/OemAuthForm";
import PageLayout from "../components/layouts/PageLayout";

const OemAuthPage: React.FC = () => {
  return (
    <PageLayout title="PA01-01: OEM認証">
      <OemAuthForm />
    </PageLayout>
  );
};

export default OemAuthPage;

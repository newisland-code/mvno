import React from "react";
import { LookupContractForm } from "../components/forms/LookupContractForm";

const LookupContractPage: React.FC = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">PA08-01: 契約情報照会</h1>
      <LookupContractForm />
    </div>
  );
};

export default LookupContractPage;

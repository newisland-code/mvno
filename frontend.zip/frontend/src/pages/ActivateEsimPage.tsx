import React from "react";
import ActivateEsimForm from "@/components/forms/ActivateEsimForm";

const ActivateEsimPage: React.FC = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">PA05-41: eSIM開通</h1>
      <ActivateEsimForm />
    </div>
  );
};

export default ActivateEsimPage;

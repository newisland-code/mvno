import React from "react";
import { ChangeContractForm } from "../components/forms/ChangeContractForm";

const ChangeContractPage: React.FC = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">PA06-01: 契約変更</h1>
      <ChangeContractForm />
    </div>
  );
};

export default ChangeContractPage;

import React from "react";
import { AddAcntForm } from "../components/forms/AddAcntForm";

const AddAcntPage: React.FC = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">PA02-01: アカウント登録</h1>
      <AddAcntForm />
    </div>
  );
};

export default AddAcntPage;

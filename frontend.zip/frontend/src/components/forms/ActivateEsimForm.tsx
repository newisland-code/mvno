// frontend/src/components/forms/ActivateEsimForm.tsx
import React, { useState } from "react";
import { planOptions } from "../../types/planOptions";
import { postToApi } from "../../services/apiClient";

export default function ActivateEsimForm() {
  const [formData, setFormData] = useState({
    eid: "",
    simKind: "E2",
    addKind: "N",
    account: "",
    repAccount: "",
    shipDate: "",
    planCode: "",
    reserveNumber: "",
    reserveExpireDate: "",
    lastnameKanji: "",
    firstnameKanji: "",
    lastnameZenKana: "",
    firstnameZenKana: "",
    gender: "M",
    birthday: "",
    oldProductNumber: "",
    oldEid: ""
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const payload: any = {
      eid: formData.eid,
      simKind: formData.simKind,
      addKind: formData.addKind,
      account: formData.account,
      repAccount: formData.repAccount,
      shipDate: formData.shipDate,
      planCode: formData.planCode,
      createType: "new",
      mnp: {
        reserveNumber: formData.reserveNumber,
        reserveExpireDate: formData.reserveExpireDate,
        lastnameKanji: formData.lastnameKanji,
        firstnameKanji: formData.firstnameKanji,
        lastnameZenKana: formData.lastnameZenKana,
        firstnameZenKana: formData.firstnameZenKana,
        gender: formData.gender,
        birthday: formData.birthday,
      },
      reissue: {
        oldProductNumber: formData.oldProductNumber,
        oldEid: formData.oldEid
      }
    };

    try {
      const result = await postToApi("/activateEsim", payload);
      console.log("✅ 開通成功: ", result);
      alert("eSIM開通が完了しました");
    } catch (err) {
      console.error("❌ エラー発生:", err);
      alert("開通に失敗しました: " + err);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-4">
      <input name="eid" value={formData.eid} onChange={handleChange} placeholder="EID" required />
      <input name="account" value={formData.account} onChange={handleChange} placeholder="電話番号 (account)" required />
      <input name="repAccount" value={formData.repAccount} onChange={handleChange} placeholder="代表番号 (repAccount)" />
      <input name="shipDate" value={formData.shipDate} onChange={handleChange} placeholder="出荷日 (YYYYMMDD)" />
      <select name="planCode" value={formData.planCode} onChange={handleChange} required>
        <option value="">プランを選択</option>
        {planOptions.map((opt) => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
      <hr />
      <input name="reserveNumber" value={formData.reserveNumber} onChange={handleChange} placeholder="MNP予約番号" required />
      <input name="reserveExpireDate" value={formData.reserveExpireDate} onChange={handleChange} placeholder="有効期限 (YYYYMMDD)" />
      <input name="lastnameKanji" value={formData.lastnameKanji} onChange={handleChange} placeholder="姓（漢字）" />
      <input name="firstnameKanji" value={formData.firstnameKanji} onChange={handleChange} placeholder="名（漢字）" />
      <input name="lastnameZenKana" value={formData.lastnameZenKana} onChange={handleChange} placeholder="姓（カナ）" />
      <input name="firstnameZenKana" value={formData.firstnameZenKana} onChange={handleChange} placeholder="名（カナ）" />
      <select name="gender" value={formData.gender} onChange={handleChange}>
        <option value="M">男性</option>
        <option value="W">女性</option>
        <option value="C">法人</option>
      </select>
      <input name="birthday" value={formData.birthday} onChange={handleChange} placeholder="誕生日 (YYYYMMDD)" />
      <hr />
      <input name="oldProductNumber" value={formData.oldProductNumber} onChange={handleChange} placeholder="旧製品番号 (再発行用)" />
      <input name="oldEid" value={formData.oldEid} onChange={handleChange} placeholder="旧EID (再発行用)" />

      <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">eSIM開通</button>
    </form>
  );
}

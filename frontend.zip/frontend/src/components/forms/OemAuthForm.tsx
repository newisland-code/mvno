// frontend/src/components/forms/OemAuthForm.tsx
import React, { useState } from "react";
import { postToApi } from "@/services/apiClient";

const OemAuthForm: React.FC = () => {
  const [oemId, setOemId] = useState("");
  const [oemPassword, setOemPassword] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const response = await postToApi("/authOem", {
        oemId,
        oemPassword,
      });
      console.log("OEM認証成功:", response);
    } catch (error: any) {
      console.error("OEM認証エラー:", error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={oemId}
        onChange={(e) => setOemId(e.target.value)}
        placeholder="OEM ID"
        required
      />
      <input
        type="password"
        value={oemPassword}
        onChange={(e) => setOemPassword(e.target.value)}
        placeholder="OEMパスワード"
        required
      />
      <button type="submit">認証</button>
    </form>
  );
};

export default OemAuthForm;
